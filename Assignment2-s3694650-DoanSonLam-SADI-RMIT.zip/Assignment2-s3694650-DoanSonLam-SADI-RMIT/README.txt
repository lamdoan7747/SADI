/// Endpoint for Patient
GET ALL method		:       localhost:8080/patients
GET Patient by name	:	localhost:8080/patients/search?name={name}
POST Patient (Add) 	:	localhost:8080/patients
PUT Patient (Update)	:	localhost:8080/patients
DELETE Patient	(Id)	:	localhost:8080/patients/delete?id={id}

---
/// Endpoint for IcdCode	
GET ALL method		:       localhost:8080/icdCodes (!! No need to use this method because there are more than 9000 diseases !!)
GET by diseaseCode	:	localhost:8080/icdCodes/search?icdCode={diseaseCode}

---
/// Endpoint for Visit
GET ALL method		:	localhost:8080/visits
GET VISIT by name	:	localhost:8080/visits/search?name={name}
POST Visit		: 	localhost:8080/visits	
(Method POST: 
	"patient":{"patient_name"},
	"icDcode":{"disease_code"},
	"problem":[
		{"name":"problem1_name"},
		{"name":"problem2_name"}, ...
	]
)
PUT Visit		:	localhost:8080/visits
DELETE Visit	(ID)	: 	localhost:8080/visits/delete?id={id}

---
/// Endpoint for Drug
GET ALL Drug		:	localhost:8080/drugs
GET Drug by ID		:	localhost:8080/drugs/search?id={id}
POST Drug		: 	localhost:8080/drugs
PUT Drug		: 	localhost:8080/drugs
DELETE Drug		: 	localhost:8080/drugs/delete?id={id}

---
/// Endpoint for Prescription
GET ALL Prescription	: 	localhost:8080/prescriptions
POST Prescription	: 	localhost:8080/prescriptions
(Method POST: 
	"quantity":"",
	"dose":"",
	"instruction":"",
	"drugs":[
		{"id":"id_1"},
		{"id":"id_2"}, ...
	]
)
PUT Prescription	:	localhost:8080/prescriptions
DELETE Prescription (ID):	localhost:8080/prescriptions/delete?id={id}

----------------------------------------------------------------------------
USED DATA:
- For Patient: 
1. {"name":"Lam","birthday":"1998-12-24","gender":"male","address":"Nha Trang"}
2. {"name":"Tai","birthday":"1999-12-15","gender":"female","address":"Japan"}
3. {"name":"Binh","birthday":"1998-09-08","gender":"male","address":"Vung Tau"}
4. {"name":"Kha","birthday":"2000-05-12","gender":"female","address":"Sai Gon"}
5. {"name":"Minh","birthday":"1997-04-30","gender":"male","address":"Tokyo"}

- For Visit:
1. {"patient":{"Lam"},"icDcode":{"disease_code"},"problem":[{"name":"Cold"},{"name":"Hot"}, ...]}
2. {"patient":{"Minh"},"icDcode":{"disease_code"},"problem":[{"name":"Headache"},{"name":"Broke"}, ...]}

- For Prescription:
1. {"quantity":"5","dose":"3 times a day","instruction":"Nothing","drugs":[{"id":"5"},{"id":"9"}, ...]}

!!! NOTICE !!!
- Patient name is unique and not null.
- Visit is posted only when IcdCode and Patient are imported. 
- Prescription is posted only when Drug is imported.

