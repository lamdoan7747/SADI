package service;

import model.IcdCode;
import model.Patient;
import model.Problem;
import model.Visit;
import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

@Service
@Transactional
public class VisitService {
    @Autowired
    private SessionFactory sessionFactory;

    // CRUD FUNCTION
    public List<Visit> getAllVisits(){
        return sessionFactory.getCurrentSession().createQuery("from Visit").list();
    }

    public List<Visit> getVisitByName(String name){
        Query query = sessionFactory.getCurrentSession().createQuery("from Visit where id in (select id from Patient where name like :name)");
        query.setString("name",name);
        return query.list();
    }

    public int addVisit(Visit visit){
        if (visit.getDate()==null && visit.getTime()==null){
            Date date = new Date();
            SimpleDateFormat formatterTime = new SimpleDateFormat("HH:mm:ss");
            SimpleDateFormat formatterDate = new SimpleDateFormat("dd-MM-yyyy");
            visit.setDate( formatterDate.format(date));
            visit.setTime(formatterTime.format(date));
        }
        //This part is not completely done
        if (visit.getProblems()!=null){
            for (Problem problem: visit.getProblems()){
                problem.getVisits().add(visit);
            }
        }

        if (visit.getPatient()!=null){
            String patient_name = visit.getPatient().getName();
            Query query = sessionFactory.getCurrentSession().createQuery("from Patient where name = :name");
            query.setParameter("name",patient_name);
            Patient patient = (Patient) query.uniqueResult();
            visit.setPatient(patient);
        }
        if (visit.getIcDcode()!=null){
            String diseaseCode = visit.getIcDcode().getDiseaseCode();
            Query query = sessionFactory.getCurrentSession().createQuery("from IcdCode where diseaseCode = :diseaseCode");
            query.setParameter("diseaseCode",diseaseCode);
            IcdCode icdCode = (IcdCode) query.uniqueResult();
            visit.setIcDcode(icdCode);
        }
        this.sessionFactory.getCurrentSession().saveOrUpdate(visit);
        return visit.getId();
    }



    public void deleteVisit(int id){
        Query query = sessionFactory.getCurrentSession().createQuery("from Visit where id = :id");
        query.setInteger("id",id);
        Visit visit = (Visit) query.uniqueResult();
        sessionFactory.getCurrentSession().delete(visit);
    }


}
