package service;

import model.Drug;
import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import javax.transaction.Transactional;
import java.util.List;

@Service
@Transactional
public class DrugService {
    @Autowired
    private SessionFactory sessionFactory;

    // CRUD FUNCTION
    public List<Drug> getAllDrugs(){
        return sessionFactory.getCurrentSession().createQuery("from Drug").list();
    }

    public int addDrugs(Drug drug){
        return (int) sessionFactory.getCurrentSession().save(drug);
    }

    public int updateDrugs(Drug drug){
        this.sessionFactory.getCurrentSession().update(drug);
        return drug.getId();
    }

    public void deleteDrug(int id){
        Query query = sessionFactory.getCurrentSession().createQuery("from Drug where id = :id");
        query.setInteger("id",id);
        Drug drug = (Drug) query.uniqueResult();
        sessionFactory.getCurrentSession().delete(drug);
    }

    public List<Drug> getDrugById(int id){
        Query query = sessionFactory.getCurrentSession().createQuery("from Drug where id = :id");
        query.setInteger("id",id);
        return query.list();
    }
}
