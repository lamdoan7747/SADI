package service;

import model.IcdCode;
import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import javax.transaction.Transactional;
import java.util.List;

@Service
@Transactional
public class ICDcodeService {
    @Autowired
    private SessionFactory sessionFactory;

    //CRUD FUNCTION
    public List<IcdCode> getAllICDcode(){
        return sessionFactory.getCurrentSession().createQuery("from IcdCode").list();
    }

    public List<IcdCode> findIcdCode(String icdCode){
        Query query = sessionFactory.getCurrentSession().createQuery("from IcdCode  where diseaseCode like :diseaseCode");
        query.setString("diseaseCode", icdCode);
        return query.list();
    }
}
