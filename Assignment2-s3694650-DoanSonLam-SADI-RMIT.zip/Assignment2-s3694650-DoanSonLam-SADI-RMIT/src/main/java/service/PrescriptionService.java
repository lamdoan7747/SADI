package service;

import model.Drug;
import model.Prescription;
import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import javax.transaction.Transactional;
import java.util.List;

@Service
@Transactional
public class PrescriptionService {
    @Autowired
    private SessionFactory sessionFactory;

    //CRUD FUNCTION
    public List<Prescription> getAllPrescriptions(){
        return sessionFactory.getCurrentSession().createQuery("from Prescription").list();
    }

    public int addPrescription(Prescription prescription){
        if (prescription.getDrugs()!=null){
            for (Drug drug: prescription.getDrugs()){
                int id = drug.getId();
                Query query = sessionFactory.getCurrentSession().createQuery("from Drug where id = :id");
                query.setInteger("id",id);
                drug = (Drug) query.uniqueResult();
                drug.getPrescriptions().add(prescription);
            }
        }
        sessionFactory.getCurrentSession().saveOrUpdate(prescription);
        return prescription.getId();
    }

    public int updatePrescription(Prescription prescription){
        if (prescription.getDrugs()!=null){
            for (Drug drug: prescription.getDrugs()){
                int id = drug.getId();
                Query query = sessionFactory.getCurrentSession().createQuery("from Drug where id = :id");
                query.setInteger("id",id);
                drug = (Drug) query.uniqueResult();
                drug.getPrescriptions().add(prescription);
            }
        }
        sessionFactory.getCurrentSession().update(prescription);
        return prescription.getId();
    }

    public void deletePrescription(int id){
        Query query = sessionFactory.getCurrentSession().createQuery("from Prescription where id = :id");
        query.setInteger("id",id);
        Prescription prescription = (Prescription) query.uniqueResult();
        sessionFactory.getCurrentSession().delete(prescription);
    }
}
