package model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "Visit")
public class Visit {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @Column
    private String date;

    @Column
    private String time;

    @ManyToOne(cascade = CascadeType.ALL)
    private Patient patient;

    @ManyToOne(cascade = CascadeType.ALL)
    private IcdCode icDcode;

    @ManyToMany(cascade = CascadeType.ALL ,fetch = FetchType.EAGER)
    @JoinTable(
            name = "PROBLEM_VISIT",
            joinColumns = {@JoinColumn(
                    name = "PROBLEM_ID"
            )},
            inverseJoinColumns = {@JoinColumn(
                    name = "VISIT_ID"
            )}
    )
    @JsonIgnoreProperties("visits")
    private List<Problem> problems = new ArrayList<>();


    public Visit() {
    }

    //Get and set

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public Patient getPatient() {
        return patient;
    }

    public void setPatient(Patient patient) {
        this.patient = patient;
    }

    public IcdCode getIcDcode() {
        return icDcode;
    }

    public void setIcDcode(IcdCode icDcode) {
        this.icDcode = icDcode;
    }

    public List<Problem> getProblems() {
        return problems;
    }

    public void setProblems(List<Problem> problems) {
        this.problems = problems;
    }

    @Override
    public String toString() {
        return "Visit{" +
                "id=" + id +
                ", date=" + date +
                ", time=" + time +
                ", patient=" + patient +
                ", icDcode=" + icDcode +
                ", problems=" + problems +
                '}';
    }
}
