package model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "Prescription")
public class Prescription {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @Column(name = "Prescription_quantity")
    private int quantity;

    @Column(name = "Prescription_dose")
    private String dose;

    @Column(name = "Prescription_instruction", length = 1000)
    private String instruction;

    @ManyToMany(cascade = CascadeType.MERGE ,fetch = FetchType.EAGER)
    @JoinTable(
            name = "DRUG_PRESCRIPTION",
            joinColumns = {@JoinColumn(
                    name = "DRUG_ID"
            )},
            inverseJoinColumns = {@JoinColumn(
                    name = "PRESCRIPTION_ID"
            )}
    )
    @JsonIgnoreProperties("prescriptions")
    private List<Drug> drugs = new ArrayList<>();



    public Prescription() {
    }

    //Get and set

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }


    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public String getDose() {
        return dose;
    }

    public void setDose(String dose) {
        this.dose = dose;
    }

    public String getInstruction() {
        return instruction;
    }

    public void setInstruction(String instruction) {
        this.instruction = instruction;
    }

    public List<Drug> getDrugs() {
        return drugs;
    }

    public void setDrugs(List<Drug> drugs) {
        this.drugs = drugs;
    }

    @Override
    public String toString() {
        return "Prescription{" +
                "id=" + id +
                ", quantity=" + quantity +
                ", dose='" + dose + '\'' +
                ", instruction='" + instruction + '\'' +
                ", drugs=" + drugs +
                '}';
    }
}
