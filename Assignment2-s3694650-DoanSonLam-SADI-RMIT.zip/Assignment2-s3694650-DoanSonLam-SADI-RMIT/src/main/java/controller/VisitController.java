package controller;

import model.Visit;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import service.VisitService;
import java.util.List;

@RestController
public class VisitController {
    @Autowired
    private VisitService visitService;

    //Method Get All
    @RequestMapping(path = "/visits", method = RequestMethod.GET)
    private List<Visit> getAllVisits(){
        return visitService.getAllVisits();
    }

    //Method Get Patient By Name
    @RequestMapping(path = "/visits/search", method = RequestMethod.GET)
    private List<Visit> getVisitByPatientName(String name){
        return visitService.getVisitByName(name);
    }

    //Method Post
    @RequestMapping(path = "/visits", method = RequestMethod.POST)
    private int addVisit(@RequestBody Visit visit){
        return visitService.addVisit(visit);
    }


    //Method Delete
    @RequestMapping(path = "/visits/delete", method = RequestMethod.DELETE)
    private void deleteVisit(@RequestParam int id){
        visitService.deleteVisit(id);
    }
}
