package controller;

import model.Drug;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import service.DrugService;
import java.util.List;

@RestController
public class DrugController {
    @Autowired
    private DrugService drugService;

    //Method Get All
    @RequestMapping(path = "/drugs", method = RequestMethod.GET)
    public List<Drug> getAllDrugs(){
        return drugService.getAllDrugs();
    }

    //Method Post
    @RequestMapping(path = "/drugs", method = RequestMethod.POST)
    public int addDrugs(@RequestBody Drug drug){
        return drugService.addDrugs(drug);
    }

    //Method Delete
    @RequestMapping(path = "/drugs/delete", method = RequestMethod.DELETE)
    public void deleteDrug(@RequestParam int id){
        drugService.deleteDrug(id);
    }

    //Method Put
    @RequestMapping(path = "/drugs", method = RequestMethod.PUT)
    public int updateDrug(@RequestBody Drug drug){
        return drugService.updateDrugs(drug);
    }

    //Method Get Drug by ID
    @RequestMapping(path = "/drugs/search", method = RequestMethod.GET)
    public List<Drug> getDrugById(int id){
        return drugService.getDrugById(id);
    }
}
