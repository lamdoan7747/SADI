package controller;

import model.IcdCode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import service.ICDcodeService;
import java.util.List;

@RestController
public class ICDcodeController {

    @Autowired
    private ICDcodeService icDcodeService;

    //Method Get All
    @RequestMapping(path = "/icdCodes", method = RequestMethod.GET)
    public List<IcdCode> getAllICDcodes(){
        return icDcodeService.getAllICDcode();
    }

    //Method Get by Code
    @RequestMapping(path = "/icdCodes/search", method = RequestMethod.GET)
    public List<IcdCode> findIcdCode(String icdCode){
        return icDcodeService.findIcdCode(icdCode);
    }
}

