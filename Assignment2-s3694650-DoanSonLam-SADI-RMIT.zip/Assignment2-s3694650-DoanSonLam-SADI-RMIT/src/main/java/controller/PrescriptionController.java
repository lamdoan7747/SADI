package controller;

import model.Prescription;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import service.PrescriptionService;
import java.util.List;

@RestController
public class PrescriptionController {
    @Autowired
    private PrescriptionService prescriptionService;

    // Method Get All
    @RequestMapping(path = "/prescriptions", method = RequestMethod.GET)
    private List<Prescription> getAllPrescriptions(){
        return prescriptionService.getAllPrescriptions();
    }

    // Method Post
    @RequestMapping(path = "/prescriptions", method = RequestMethod.POST)
    private int addPrescriptioin(@RequestBody Prescription prescription){
        return prescriptionService.addPrescription(prescription);
    }

    // Method Put
    @RequestMapping(path = "/prescriptions", method = RequestMethod.PUT)
    private int updateAllPrescription(@RequestBody Prescription prescription){
        return prescriptionService.updatePrescription(prescription);
    }

    // Method Delete
    @RequestMapping(path = "/prescriptions/delete", method = RequestMethod.DELETE)
    public void deletePrescription(@RequestParam int id){
        prescriptionService.deletePrescription(id);
    }
}
