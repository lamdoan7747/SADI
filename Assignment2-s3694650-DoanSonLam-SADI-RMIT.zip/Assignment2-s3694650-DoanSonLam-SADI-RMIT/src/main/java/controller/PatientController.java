package controller;

import model.Patient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import service.PatientService;
import java.util.List;

@RestController
public class PatientController {
    @Autowired
    private PatientService patientService;

    //Method Get All
    @RequestMapping(path = "/patients", method = RequestMethod.GET)
    public List<Patient> getAllPatients(){
        return patientService.getAllPatients();
    }

    //Method Get Patient By Name
    @RequestMapping(path = "/patients/search", method = RequestMethod.GET)
    public List<Patient> findPatientByName(String name){
        return patientService.findPatientByName(name);
    }

    //Method Post
    @RequestMapping(path = "/patients", method = RequestMethod.POST)
    public int addPatient(@RequestBody Patient patient) {
        return patientService.addPatient(patient);
    }

    //Method Delete
    @RequestMapping(path = "/patients/delete", method = RequestMethod.DELETE)
    public void deleteDrug(@RequestParam int id){
        patientService.deletePatient(id);
    }

    //Method Put
    @RequestMapping(path = "/patients", method = RequestMethod.PUT)
    public int updateDrug(@RequestBody Patient patient){
        return patientService.updatePatient(patient);
    }
}
